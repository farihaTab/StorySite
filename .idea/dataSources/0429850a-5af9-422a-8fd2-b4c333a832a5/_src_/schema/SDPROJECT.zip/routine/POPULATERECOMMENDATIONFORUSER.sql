create FUNCTION populateRecommendationForUser ( uname IN VARCHAR2)
RETURN NUMBER IS
  i NUMBER;
  BEGIN
    DELETE FROM RECOMMENDEDCATEGORY WHERE INTERESTED = uname ;
    DELETE FROM RECOMMENDEDTAG WHERE INTERESTED = uname  ;
    DELETE FROM RECOMMENDEDSTORY WHERE INTERESTED = uname ;

      DBMS_OUTPUT.PUT_LINE('username '||uname) ;
      findInterestedCategory(uname);
      findInterestedTag(uname);
      findInterestedStory(uname);
    RETURN 0;
  END ;
