create PROCEDURE populateRecommendation IS
  i NUMBER;
  BEGIN
    DELETE FROM RECOMMENDEDCATEGORY;
    DELETE FROM RECOMMENDEDTAG;
    DELETE FROM RECOMMENDEDSTORY;

    i:=0;
    DBMS_OUTPUT.PUT_LINE('Starting') ;
    FOR R IN ( select USERNAME from ACCOUNTUSER)
    LOOP
      DBMS_OUTPUT.PUT_LINE('username '||R.USERNAME) ;
      findInterestedCategory(R.USERNAME);
      findInterestedTag(R.USERNAME);
      findInterestedStory(R.USERNAME);
    END LOOP;
  END ;