create PROCEDURE findInterestedCategory ( uname IN VARCHAR2) IS
  i NUMBER;
BEGIN
  i:=0;

  FOR R IN ( select STORY.CATEGORYNAME , count(*) total
              from likes join STORY
              On LIKES.LIKEDSTORY = STORY.STORYID
                WHERE LIKES.LIKEDBY = uname
              GROUP BY STORY.CATEGORYNAME
              ORDER BY total DESC
  )
  LOOP
    DBMS_OUTPUT.PUT_LINE('cat '||R.CATEGORYNAME) ;
    INSERT INTO RECOMMENDEDCATEGORY (INTERESTED, INTERESTEDIN, INTERESTRATING)
      VALUES (uname, R.CATEGORYNAME, i+1);
    i := i+1;
    EXIT WHEN (i = 5 ) ;
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE('I dont know what happened!') ;

END ;