create PROCEDURE findInterestedStory ( uname IN VARCHAR2) IS
  i NUMBER;
  j NUMBER;
  nbour VARCHAR2(20);
  sid NUMBER;
  BEGIN
    i:=0;
    j := 0;
    FOR R IN (
            select RC.INTERESTED neighbour , COUNT(RC.INTERESTED) total
            from RECOMMENDEDCATEGORY rc join RECOMMENDEDTAG rt
            on RC.INTERESTED = RT.INTERESTED
            WHERE RT.INTERESTED <> uname
            AND RC.INTERESTEDIN in (SELECT r.INTERESTEDIN from RECOMMENDEDCATEGORY r WHERE r.INTERESTED = uname)
            AND RT.INTERESTEDIN in (SELECT rr.INTERESTEDIN from RECOMMENDEDTAG rr WHERE rr.INTERESTED = uname)
            GROUP BY RC.Interested
            ORDER BY total desc
    )
    LOOP
      DBMS_OUTPUT.PUT_LINE('neighbour '||R.neighbour) ;
      nbour := R.neighbour;

      FOR R IN (  SELECT LIKEDSTORY
                  FROM LIKES
                  WHERE LIKEDBY = nbour
                  AND LIKEDSTORY not in (SELECT LIKEDSTORY from LIKES WHERE LIKEDBY = uname)
                  AND LIKEDSTORY IN (SELECT storyid
                  FROM STORY
                  WHERE CATEGORYNAME IN  (SELECT INTERESTEDIN
                  FROM RECOMMENDEDCATEGORY
                  WHERE INTERESTED = uname)
                  )
      )
      LOOP
        SELECT count(INTERESTEDIN) into sid FROM RECOMMENDEDSTORY WHERE INTERESTED = uname AND INTERESTEDIN = R.LIKEDSTORY;
        IF sid = 0 THEN
          INSERT INTO RECOMMENDEDSTORY (INTERESTED, INTERESTEDIN, INTERESTRATING)
          VALUES (uname, R.LIKEDSTORY, j+1);
          j := j+1;
          END IF ;
      END LOOP;
      i := i+1;
      EXIT WHEN (j = 25 ) ;
    END LOOP;
/*EXCEPTION
WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE('I dont know what happened!') ;*/
  END ;