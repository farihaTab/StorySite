create PROCEDURE findInterestedTag ( uname IN VARCHAR2) IS
  i NUMBER;
  avgcount NUMBER;
  BEGIN
    i:=0;
    avgcount := 0;
    FOR R IN ( select TAGNAME, COUNT(*) TOTAL
               from STORYTAG JOIN LIKES
                   ON STORYTAG.TAGGEDSTORY = LIKES.LIKEDSTORY
               WHERE LIKES.LIKEDBY = uname
               GROUP BY STORYTAG.TAGNAME
               ORDER BY TOTAL ASC)
    LOOP
      DBMS_OUTPUT.PUT_LINE('tag '||R.TAGNAME) ;
      avgcount := avgcount+R.TOTAL;
      INSERT INTO RECOMMENDEDTAG (INTERESTED, INTERESTEDIN, INTERESTRATING)
      VALUES (uname, R.TAGNAME, i+1);
      i := i+1;
      EXIT WHEN (i = 5 ) ;
    END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('I dont know what happened!') ;
  END ;